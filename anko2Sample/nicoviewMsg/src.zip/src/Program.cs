﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//参照設定にもSystem.Runtime.Remotingを追加すること
using nicoviewLink;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;

namespace nicoviewMsg
{
    class Program
    {
        const string ankoname = "やります！アンコちゃん";

        static void Main(string[] args)
        {
            using (var mutex = new System.Threading.Mutex(false, ankoname))
            {
                if (mutex.WaitOne(0, false))
                {
                    Console.WriteLine("nicoviewMsg:やります！アンコちゃんが起動していません");
                    dispHelp();
                    return;
                }
            }
            ChannelServices.RegisterChannel(new IpcClientChannel(), true);
            RemotingConfiguration.RegisterWellKnownClientType(
                typeof(nicoviewLink.RemoteObject), "ipc://" + ankoname + "/Program");

            nicoviewLink.RemoteObject remo = new nicoviewLink.RemoteObject();

            if (args.Length == 4 && args[0] == "/unei")
            {
                remo.RemotePostOwnerComment(args[1], args[2], args[3]);
            }
            else if (args.Length == 3 && args[0] == "/normal")
            {
                remo.RemotePostComment(args[1], args[2]);
            }
            else if (args.Length == 4 && args[0] == "/bsp")
            {
                remo.RemotePostBSPComment(args[1], args[2], args[3]);
            }
            else
            {
                dispHelp();
            }
        }
        static void dispHelp()
        {
            Console.WriteLine("\n\nnicoviewMsg:接続中のやりますアンコちゃんからメッセージを送ります");
            Console.WriteLine("運営コメント送信");
            Console.WriteLine("　nicoviewMsg /unei \"名前\" \"メッセージ\" \"コマンド\" \n");
            Console.WriteLine("通常コメント送信");
            Console.WriteLine("　nicoviewMsg /normal \"メッセージ\" \"コマンド\" \n");
            Console.WriteLine("BSPコメント送信");
            Console.WriteLine("　nicoviewMsg /bsp \"名前\" \"メッセージ\" \"色\" \n");

        }
    }

}
